#ifndef __wws2812_H
#define __wws2812_H




//const int PIN_TX = 16;

void put_pixel(uint32_t pixel_grb) ;

uint32_t urgb_u32(uint8_t r, uint8_t g, uint8_t b);


#endif
